# change extract.sources in yw.properties first

# Run following commands:
  yw graph
  dot -Tpng combined.gv -o combined.png

# rename combined.gv and combined.png
